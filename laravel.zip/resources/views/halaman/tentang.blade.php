@extends('layout/aplikasi')
@section('konten')
    <h1>{{$halaman_tentang}}</h1>
    <p>{{$deskripsi_tentang}}</p>
@endsection
