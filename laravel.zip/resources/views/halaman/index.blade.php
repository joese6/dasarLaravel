@extends('layout/aplikasi')
@section('konten')
    <h1>{{$halaman_index}}</h1>
    <p>{{$deskripsi_index}}</p>
@endsection
