
<?php $__env->startSection('konten'); ?>
    <a href="/siswa/create" class="btn btn-primary">+ Tambah Data Siswa</a>
    <table class="table">
        <thead>
            <tr>
                <th>Foto</th>
                <th>NIS</th>
                <th>Nama</th>
                <th>Alamat</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php if($item->foto): ?>
                            <img style="max-width:50px;max-height:50px" src="<?php echo e(url('foto').'/'.$item->foto); ?>">
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($item->nis); ?></td>
                    <td><?php echo e($item->nama); ?></td>
                    <td><?php echo e($item->alamat); ?></td>
                    <td>
                        <a href='<?php echo e(url('/siswa/' . $item->nis)); ?>' class='btn btn-secondary btn-sm'>Detail</a>
                        <a href='<?php echo e(url('/siswa/' . $item->nis.'/edit')); ?>' class='btn btn-warning btn-sm'>Edit</a>
                        <form onsubmit="return confirm('Apakah yakin data dihapus?')" class="d-inline" action="<?php echo e('/siswa/'.$item->nis); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger btn-sm" type="submit">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($data->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\resources\views/siswa/index.blade.php ENDPATH**/ ?>