
<?php $__env->startSection('konten'); ?>
    <h1><?php echo e($halaman_tentang); ?></h1>
    <p><?php echo e($deskripsi_tentang); ?></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/aplikasi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\resources\views/halaman/tentang.blade.php ENDPATH**/ ?>