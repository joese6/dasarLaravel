
<?php $__env->startSection('konten'); ?>
    <a href='/siswa' class='btn btn-secondary'><< KEMBALI</a>
            <form method="POST" action="<?php echo e('/siswa/'.$data->nis); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <div class="mb-3">
                    <h1>Nomor Induk Siswa: <?php echo e($data->nis); ?></h1>
                </div>
                <div class="mb-3">
                    <label for="nama" class="form-label">Nama Siswa</label>
                    <input type="text" class="form-control" name="nama" id="nama"
                        value="<?php echo e($data->nama); ?>">
                </div>
                <div class="mb-3">
                    <label for="alamat" class="form-label">Alamat</label>
                    <textarea class="form-control" name="alamat" id="alamat"><?php echo e($data->alamat); ?></textarea>
                </div>
                <div class="mb-3">
                    <button type="submit" class="btn btn-primary">UPDATE</button>
                </div>
            </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\resources\views/siswa/edit.blade.php ENDPATH**/ ?>