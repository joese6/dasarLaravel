
<?php $__env->startSection('konten'); ?>
    <div>
        <a href='/kel' class='btn btn-secondary'><< KEMBALI</a>
        <h1><?php echo e($data->nama_kelas); ?></h1>
        <p>
            <b>Wali Kelas: </b><?php echo e($data->walikelas); ?>

        </p>
        <p>
            <b>Jumlah Siswa: </b><?php echo e($data->jumlah_siswa); ?>

        </p>
        <p>
            <b>Foto: </b>
            <img src="<?php echo e(file_exists(public_path('kelas/' . $data->foto)) && $data->foto ? url('kelas') . '/' . $data->foto : url('kelas/no-photo.png')); ?>"
                style="max-width: 50px; max-height:50px">
        </p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\resources\views/kelas/detail.blade.php ENDPATH**/ ?>