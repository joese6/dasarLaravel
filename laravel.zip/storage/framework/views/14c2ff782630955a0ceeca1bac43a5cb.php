
<?php $__env->startSection('konten'); ?>
    <h1><?php echo e($judul); ?></h1>
    <p>Ini Halaman blade template laravel</p>
    <p>
        <ul>
            <li>Email : <?php echo e($kontak['email']); ?></li>
            <li>Instagram : <?php echo e($kontak['ig']); ?></li>
        </ul>
    </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/aplikasi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\resources\views/halaman/kontak.blade.php ENDPATH**/ ?>