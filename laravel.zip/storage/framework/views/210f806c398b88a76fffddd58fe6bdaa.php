
<?php $__env->startSection('konten'); ?>
    <div>
        <a href='/siswa' class='btn btn-secondary'>
            << KEMBALI</a>
                <h1><?php echo e($data->nama); ?></h1>
                <p>
                    <b>Nomor Induk Siswa: </b><?php echo e($data->nis); ?>

                </p>
                <p>
                    <b>Alamat: </b><?php echo e($data->alamat); ?>

                </p>
                <p>
                    <b>Foto: </b>
                    <img src="<?php echo e(file_exists(public_path('foto/' . $data->foto)) && $data->foto ? url('foto') . '/' . $data->foto : url('foto/no-photo.png')); ?>"
                        style="max-width: 50px; max-height:50px">
                </p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\resources\views//siswa/detail.blade.php ENDPATH**/ ?>