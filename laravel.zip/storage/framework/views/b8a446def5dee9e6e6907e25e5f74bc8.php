
<?php $__env->startSection('konten'); ?>
    <form method="POST" action="/kelas" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="nmkelas" class="form-label">Nama Kelas</label>
            <input type="text" class="form-control" name="nmkelas" id="nmkelas" value="<?php echo e(Session::get('nmkelas')); ?>"> 
        </div>
        <div class="mb-3">
            <label for="walas" class="form-label">Nama Wali Kelas</label>
            <input type="text" class="form-control" name="walas" id="walas" value="<?php echo e(Session::get('walas')); ?>">
        </div>
        <div class="mb-3">
            <label for="jmlsiswa" class="form-label">Jumlah Siswa</label>
            <input type="text" class="form-control" name="jmlsiswa" id="jmlsiswa" value="<?php echo e(Session::get('jmlsiswa')); ?>">
        </div>
        <div class="mb-3">
            <label for="foto" class="form-label">Foto</label>
            <input type="file" class="form-control" name="foto" id="foto">
        </div>
        <div class="mb-3">
            <button type="submit" class="btn btn-primary">SIMPAN</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\resources\views//kelas/create.blade.php ENDPATH**/ ?>